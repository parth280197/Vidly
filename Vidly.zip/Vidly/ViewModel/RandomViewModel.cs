﻿using System.Collections.Generic;
using Vidly.Models;

namespace Vidly.ViewModel
{
  public class RandomViewModel
  {
    public Movie Movie { get; set; }
    public List<Customer> Customers { get; set; }

  }
}